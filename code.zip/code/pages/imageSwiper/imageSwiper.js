// pages/imageSwiper/imageSwiper.js
Page({
  data: {
    slider: [{
      img: '../../img/banner.png',
      id: 0
    }, {
      img: '../../img/banner1.png',
      id: 1
    }],
  },
})