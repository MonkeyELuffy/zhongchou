//应写入腾讯地图的key，并改文件名为config.js
module.exports = {
  key: "QQFBZ-YLP3F-CGKJW-NU7ZJ-3JYQ7-HZFXR",
}
